# UAS_2024_211011402059_RIZKY DZAKI MUHTADIN
berikut project untuk uas membuat aplikasi flutter untuk menampilkan data harga crypto menggunakan API
